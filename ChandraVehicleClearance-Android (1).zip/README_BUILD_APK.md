# CHANDRA AUTOMOBILE VEHICLE CLEARANCE - ANDROID NATIVE APP
## CHANDRA AUTOMOBILE INDIA PRIVATE LIMITED

### Project Overview
This project contains the complete native Android Jetpack & Offline Web Assets package for **CHANDRA AUTOMOBILE VEHICLE CLEARANCE**.

- **Offline Embedded UI:** The full application UI (Vehicle Clearance Form, 11 Particulars, 7 Offers, Ledgers, Reports, Dashboard, and Login) is bundled directly inside the APK under `assets/www/`. It launches instantly on any phone without "Page Not Found" errors.
- **Cloud Database:** Firebase Cloud Firestore & Authentication syncs live whenever internet (Wi-Fi/Mobile) is active.
- **Multi-Branch Real-Time Sync:** Data synchronizes across devices instantly.
- **Admin & Executive Roles:** Strict branch and executive view restrictions.

### How to Build the APK in GitHub Actions (100% Free):
1. Go to https://github.com and log in.
2. Click **New** to create a new repository (e.g. `ChandraVehicleClearance`).
3. Click **Add file** -> **Upload files**.
4. Drag and drop **ChandraVehicleClearance-Android.zip** into the upload box and click **Commit changes**.
5. Click **Actions** at the top of the repository.
6. The workflow will run and turn **GREEN**.
7. Click the workflow run, scroll down to **Artifacts**, and click **ChandraVehicleClearance-APK** to download your APK!

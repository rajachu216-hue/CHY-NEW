package com.chandra.vehicleclearance.data

data class VehicleRecord(
    val id: String = "",
    val branch_code: String = "",
    val branch_name: String = "",
    val customer_name: String = "",
    val customer_id: String = "",
    val model: String = "",
    val vin: String = "",
    val executive: String = "",
    val finance: String = "",

    // Particulars
    val basic_price: Double = 0.0,
    val basic_accessories: Double = 0.0,
    val insurance: Double = 0.0,
    val tcs: Double = 0.0,
    val rto: Double = 0.0,
    val proceedings: Double = 0.0,
    val ext_wty: Double = 0.0,
    val sot: Double = 0.0,
    val direct_perm: Double = 0.0,
    val temp_perm: Double = 0.0,
    val notary: Double = 0.0,

    // Offers
    val chandra_offer: Double = 0.0,
    val cash_offer: Double = 0.0,
    val hmil_offer: Double = 0.0,
    val accessories_offer: Double = 0.0,
    val insurance_offer: Double = 0.0,
    val sambandh: Double = 0.0,
    val exchange_offer: Double = 0.0,

    val status: String = "PENDING",
    val remarks: String = "",
    val saved_on: String = ""
)

data class AppUser(
    val id: String = "",
    val userId: String = "",
    val executiveName: String = "",
    val passwordHash: String = "",
    val role: String = "EXECUTIVE",
    val accountStatus: String = "ENABLED",
    val assignedBranches: List<String> = emptyList(),
    val assignedExecutives: List<String> = emptyList(),
    val permissions: Map<String, Boolean> = emptyMap()
)
